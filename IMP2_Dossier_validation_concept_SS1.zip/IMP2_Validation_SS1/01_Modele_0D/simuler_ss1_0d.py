"""SS1 original : cinq volumes homogènes. Vérification numérique, pas validation physique.
Exécuter : python simuler_ss1_0d.py
"""
from pathlib import Path
import json,platform
import numpy as np
import scipy
from scipy.linalg import expm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
M=np.array([6.,3.,5.,3.,3.]); CP=4180.; POWER=1000.; UA=100.; COLD=20.

def model(n):
    q=np.sqrt(10000*n*n/(2e11+8e11)); md=1000*q
    A=np.zeros((5,5)); b=np.zeros(5)
    for i in range(5):
        A[i,i]=-md/M[i];A[i,(i-1)%5]=md/M[i]
    A[2,2]-=UA/(M[2]*CP)
    b[0]=POWER/(M[0]*CP);b[2]=UA*COLD/(M[2]*CP)
    eq=np.linalg.solve(A,-b)
    return A,b,eq,md,(.1+8e11*q*q/1e6)

def trial(n,start,dt):
    A,b,eq,md,pressure=model(n)
    t=np.arange(round(7200/dt)+1)*dt
    T=np.empty((len(t),5));T[0]=start
    exact=np.empty_like(T);exact[0]=start;E=expm(A*dt)
    initial_energy=np.dot(M*CP,start);net=0.;max_res=0.
    for k in range(len(t)-1):
        net+=dt*(POWER-UA*(T[k,2]-COLD))
        T[k+1]=T[k]+dt*(A@T[k]+b)
        exact[k+1]=eq+E@(exact[k]-eq)
        max_res=max(max_res,abs(np.dot(M*CP,T[k+1])-initial_energy-net))
    return t,T,dict(dt_s=dt,temperature_finale_V1_C=float(T[-1,0]),equilibre_V1_C=float(eq[0]),debit_kg_s=md,pression_absolue_MPa=pressure,erreur_temporelle_max_C=float(abs(T-exact).max()),residu_energie_max_J=float(max_res),residu_energie_pct_chauffage=float(100*max_res/(7200*POWER)),masse_totale_kg=float(M.sum()),constante_temps_min_s=float(1/max(-np.linalg.eigvals(A).real)))

_,_,eq_nom,_,_=model(1.)
results={'statut':'verification numerique du modele propose; coefficients hydrauliques non valides experimentalement','versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__}}
fig,axs=plt.subplots(3,1,figsize=(9,6),sharex=True,layout='constrained')
for label,n,start in [('chauffe',1.,np.full(5,20.)),('baisse_pompe',.7,eq_nom)]:
    results[label]=[]
    for dt in [1.,.5,.25]:
        t,T,r=trial(n,start,dt);results[label].append(r)
        if dt==1.:
            np.savetxt(ROOT/(label+'.csv'),np.c_[t,T,np.full(len(t),r['debit_kg_s']),np.full(len(t),r['pression_absolue_MPa'])],delimiter=',',header='temps_s,T1_C,T2_C,T3_C,T4_C,T5_C,debit_kg_s,pression_MPa',comments='')
            if label=='baisse_pompe':
                axs[0].plot(t/60,T[:,0]);axs[1].plot(t/60,np.full(len(t),r['debit_kg_s']));axs[2].plot(t/60,np.full(len(t),r['pression_absolue_MPa']))
axs[0].set_ylabel('T sortie V1 (°C)');axs[1].set_ylabel('Débit (kg/s)');axs[2].set(ylabel='Pression (MPa)',xlabel='Temps après baisse de vitesse (min)')
for ax in axs:ax.grid(alpha=.2)
fig.savefig(ROOT/'reponse_baisse_vitesse.png',dpi=170)
(ROOT/'resultats_0d.json').write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(results,indent=2,ensure_ascii=False))
