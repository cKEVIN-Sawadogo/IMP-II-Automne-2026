"""Ordres de grandeur internes au scénario, sans validation d'une pompe réelle."""
from pathlib import Path
import json,math
ROOT=Path(__file__).resolve().parent
rho=1000.;cp=4180.;g=9.81
def point(n=1.,P=1000.,UA=100.):
    q=math.sqrt(10000*n*n/(2e11+8e11));md=rho*q
    dp=8e11*q*q
    return dict(vitesse_relative=n,P_W=P,UA_W_K=UA,q_L_min=q*60000,md_kg_s=md,delta_p_Pa=dp,hauteur_m=dp/(rho*g),pression_ref_MPa=.1+dp/1e6,puissance_hydraulique_W=q*dp,T3_equilibre_C=20+P/UA,T1_equilibre_C=20+P/UA+P/(md*cp),hausse_chauffage_K=P/(md*cp))
normal=point();reduced=point(.7)
D=.020;pipeV=.009;L=pipeV/(math.pi*D*D/4);v=normal['q_L_min']/60000/(math.pi*D*D/4)
losses=[f*L/D*rho*v*v/2 for f in [.03,.04]]
data={'statut':'justification preliminaire du scenario; aucun parametre identifie sur une pompe ou un echangeur reels',
 'capacite_totale_J_K':20*cp,'pente_initiale_moyenne_K_min':1000/(20*cp)*60,'temps_min_chauffer_10K_sans_pertes_s':20*cp*10/1000,
 'nominal':normal,'vitesse_70pct':reduced,
 'volumes':{'litres':[6,3,5,3,3],'temps_passage_nominal_s':[60,30,50,30,30],'temps_passage_70pct_s':[6/.07,3/.07,5/.07,3/.07,3/.07]},
 'sensibilite_P':[point(P=p) for p in [800,1000,1200]],'sensibilite_UA':[point(UA=u) for u in [80,100,120]],
 'sensibilite_volume':{'totaux_L':[16,20,24],'facteurs_duree_meme_reponse':[.8,1,1.2],'equilibres_inchanges':True},
 'geometrie_illustrative_non_retenue':{'diametre_interieur_m':D,'volume_total_trois_segments_m3':pipeV,'longueur_totale_m':L,'vitesse_nominale_m_s':v,'facteurs_Darcy_supposes':[.03,.04],'pertes_droites_Pa':losses,'reste_pour_composants_Pa':[normal['delta_p_Pa']-x for x in losses]},
 'pompe':{'hauteur_fermeture_n1_m':10000/(rho*g),'debit_hauteur_nulle_n1_L_min':math.sqrt(10000/2e11)*60000,'pente_difference_pompe_reseau_nominal_Pa_s_m3':-2*(2e11+8e11)*.0001}}
(ROOT/'justification_parametres.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(data,indent=2,ensure_ascii=False))
