# IMP2 — Dossier de validation du concept SS1

## Commencer
Lire 05_Rapport/IMP2_Section_2_1_SS1.docx, puis 04_Integration/PROTOCOLE.md. Le concept livré reste le 0D initial à cinq volumes. L'ajout paroi–pertes dans les essais est une comparaison, pas une modification silencieuse du modèle de boucle. Le dossier ne contient pas le modèle hybride 1D de l'option de repli.

## Contenu
- 01_Modele_0D : modèle autonome de la boucle, CSV, figure et résultats numériques régénérables ; calcul des ordres de grandeur et sensibilités avec justifier_parametres.py.
- 02_Essais_conduites : cinq jeux expérimentaux originaux de Liège, code 0D initial et variante paroi–pertes, comparaison aux mesures, erreurs, figure du transitoire lent, analyse détaillée et provenance.
- 03_Essai_reservoir : reconstruction de la figure expérimentale de Thornhill et al., modèle simplifié, résultats et limites de reconstruction. Ce dossier n'est pas une acquisition brute.
- 04_Integration : protocole des essais restants avec SS2, SS3 et SS4, fiche de résultats vide. Les modules de l'équipe ne sont pas remplacés par des simulations factices.
- 05_Rapport : document Word de base SS1 mis à jour, références et liste des principales modifications.

## Exécution sous Windows PowerShell
Depuis le dossier décompressé, utiliser Python Windows 3.13 comme dans les essais précédents :

```powershell
py -3.13 -m venv .venv313
.\.venv313\Scripts\python.exe -m pip install --only-binary=:all: -r requirements.txt
.\.venv313\Scripts\python.exe 01_Modele_0D\simuler_ss1_0d.py
.\.venv313\Scripts\python.exe 01_Modele_0D\justifier_parametres.py
.\.venv313\Scripts\python.exe 02_Essais_conduites\essais.py
.\.venv313\Scripts\python.exe 03_Essai_reservoir\reproduire.py
```

Un environnement .venv313 existant peut être réutilisé en appelant son chemin complet. Ces scripts ne demandent pas CoolProp, Modelica ou MATLAB. Les fichiers de mesure nécessaires sont inclus ; aucun téléchargement n'est effectué pendant l'exécution. Les résultats sont écrits dans le dossier de chaque script. L'installation des dépendances demande Internet.

## Lire les résultats sans surestimer la preuve
Vérification numérique : bilans et convergence du modèle proposé. Appui expérimental : 0D thermique comparé à des composants réels documentés. Validation de la chaîne de surveillance : encore à réaliser. L'essai lent de conduite donne environ 0,32 °C de RMSE et 0,84 °C d'écart maximal pour le 0D initial ; cela ne valide ni l'hydraulique ni la boucle complète. Les erreurs des essais rapides sont conservées. Les tolérances de fidélité p. 25 du rapport de concepts sont des propositions à fixer avec une métrique, pas des résultats.

Les fichiers resultats*.json indiquent les versions et les indicateurs effectivement calculés. Les versions de référence sont figées dans requirements.txt ; les essais ont été exécutés ici sous Python 3.12, et les commandes ci-dessus visent votre installation Python 3.13. Les derniers chiffres peuvent varier légèrement entre environnements. Rejouer les scripts sur le poste de remise et conserver les sorties.

## Complément de justification préliminaire
Le Word contient maintenant les ordres de grandeur des volumes, du chauffage, de la conductance et du réseau hydraulique, ainsi que la distinction entre les preuves attendues maintenant et les confirmations ultérieures. Les coefficients de pompe restent proposés ; les lois de similitude et le calcul de pertes justifient leur forme et leur cohérence, sans valider un équipement réel. Les échéances C1 et essais de chaîne prévues au rapport de concepts restent applicables.
