# Repères dans le document SS1 mis à jour

- Pages 1–3 : structure de base conservée ; rôle, interfaces, cinq volumes, équations, paramètres et essais numériques. Résidus d'énergie actualisés après réexécution ; distinction entre conservation numérique et exactitude physique.
- Page 4 : résultats expérimentaux du réservoir et de la conduite lente, figure des mesures et limites de la preuve.
- Page 5 : erreurs des quatre essais rapides, domaine proposé, comparaison indicative aux tolérances du rapport de concepts et essais de chaîne encore à réaliser.
- Page 6 : justification des volumes, du chauffage, de la conductance et sensibilités exploratoires.
- Page 7 : justification hydraulique, contrôle géométrique illustratif et répartition préliminaire / travaux ultérieurs.
- Page 8 : références bibliographiques et liens vers les sources et les données, dont DOE et KSB.

## Points à harmoniser lors de l'intégration au rapport d'équipe
1. Le plan p. 18 annonce une référence de fidélité supérieure, alors que le rapport de concepts p. 21–22 retient un SS3 réduit. Consigner cette évolution et clarifier les rôles, sans transformer silencieusement SS3 en modèle de vérité.
2. Le rapport de concepts p. 26 excluait une validation physique faute de banc. Décrire maintenant les comparaisons publiées comme un appui expérimental partiel de composants ; conserver la limite concernant la boucle complète.
3. Fixer une valeur et une métrique pour les tolérances p. 25 avant de conclure à la conformité. Le résultat thermique d'une conduite ne valide pas les tolérances hydrauliques.
4. Harmoniser « plus de N=3 cycles » et « au troisième cycle » pour la perte de communication. Le protocole indique cette ambiguïté avant essai.
5. Vérifier les numéros de figures et de références après fusion dans le rapport d'équipe. Les numéros [1]–[5] sont locaux à cette section autonome.
