# IMP2 — Essais complémentaires et décision sur le concept SS1

## Conclusion pour l'équipe
Le concept 0D ne doit pas être rejeté : il reproduit bien un essai réel de montée et de descente lentes, et non seulement des plateaux. Il ne convient toutefois pas, dans sa représentation actuelle des conduites, à tous les transitoires rapides examinés. La recommandation est de conserver la famille 0D pour les scénarios thermiques lents du prototype, à condition de préciser ce domaine et l'erreur admissible. Si les démarrages et changements rapides doivent être physiquement représentatifs et utilisés pour le diagnostic, une adaptation du transport dans les conduites reste nécessaire. Ce choix ne peut pas être tranché par une RMSE moyenne seule.

## 1. Essai réel lent enfin disponible
Jeu PipeDataULg160104_2 : mesures du 4 janvier 2016, Université de Liège, distribuées dans Buildings. Durée 10176,5 s, soit 169,61 min ; 2038 points. Débit mesuré constant de 0,2494 kg/s. Température d'entrée de 17,9 °C au début, maximum de 34,7 °C à 6626,4 s, puis 21,1 °C à la fin. La température de sortie mesurée commence à 15,0 °C. Il s'agit d'un essai distinct des deux premiers essais rapides déjà examinés.

Sources primaires :
- Documentation des jeux et conditions initiales : https://simulationresearch.lbl.gov/modelica/releases/v14.0.0/help/Buildings_Fluid_FixedResistances_Validation_PlugFlowPipes_Data.html
- Géométrie et structure des colonnes : https://simulationresearch.lbl.gov/modelica/releases/latest/help/Buildings_Fluid_FixedResistances_Validation_PlugFlowPipes_Data_BaseClasses.html
- Données : https://github.com/lbl-srg/modelica-buildings/tree/master/Buildings/Resources/Data/Fluid/FixedResistances/Validation/PlugFlowPipes
- Publication : van der Heijde et al. (2017), Dynamic equation-based thermo-hydraulic pipe model for district heating and cooling systems, Energy Conversion and Management 151, 158–169. DOI https://doi.org/10.1016/j.enconman.2017.08.072 . Rapport auteur accessible : https://eta-publications.lbl.gov/sites/default/files/wetter_-_dynamic_equation.pdf

Les données mesurées sont utilisées directement. Elles n'ont pas été ralenties, étirées dans le temps ou remplacées par une rampe artificielle.

## 2. Deux représentations testées sans recalage
### A — Modèle 0D initial de conduite
rho V cp dT/dt = mdot cp (Tin − T).
Un seul état thermique, correspondant à la température homogène de l'eau ; paroi et pertes absentes. Géométrie du banc : longueur 39 m, diamètre intérieur 0,05248 m, donnant V = 0,08436108 m³. rho = 1000 kg/m³ ; cp = 4180 J/(kg K). La géométrie est celle du banc réel, pas celle proposée pour la boucle de 20 L du projet. Les équations de conduite sont les mêmes que celles du concept initial.

### B — Adaptation légère restant 0D
(rho V cp + Cparoi) dT/dt = mdot cp (Tin − T) − UA(T − Tamb).
Un seul état également : eau et paroi supposées à la même température. Cette hypothèse d'équilibre instantané eau–paroi est une simplification supplémentaire à déclarer. Diamètre extérieur 0,0603 m, acier 7800 kg/m³ et 480 J/(kg K), isolation 13 mm avec conductivité nominale 0,04 W/(m K), échange extérieur supposé 5 W/(m² K), ambiance 18 °C. Cparoi = 101141,45 J/K ; Ceau = 352629,32 J/K ; UA = 18,0214 W/K. Le calcul de UA utilise la résistance cylindrique de l'isolation et la convection extérieure, sans résistance propre de l'acier ni résistance interne explicite. L'isolant réel est signalé comme vieilli : sa valeur nominale est donc une hypothèse, pas une mesure garantie. Ces paramètres sont repris de la documentation, sans optimisation sur les courbes comparées.

### Procédure commune
Entrées : température d'entrée et débit mesurés, interpolés linéairement. Initialisation du modèle à la première température de sortie mesurée, sans réinitialisation ultérieure. Cette initialisation homogène est incertaine, puisque les températures d'entrée et de sortie initiales diffèrent. Intégration solve_ivp, rtol=1e-8, atol=1e-9, pas maximal 1 s ; comparaison aux instants originaux, sans retirer les points défavorables. RMSE = sqrt(moyenne((Tcalcul−Tmesure)²)), MAE = moyenne(abs(Tcalcul−Tmesure)). Les valeurs de sortie mesurées ne servent pas à corriger l'état pendant l'essai.

## 3. Résultats de l'essai lent complet
| Indicateur | A — 0D initial | B — 0D avec paroi et pertes |
|---|---:|---:|
| RMSE (°C) | 0,3237 | 0,2190 |
| MAE (°C) | 0,3083 | 0,1682 |
| Écart maximal absolu (°C) | 0,8376 | 0,9439 |
| RMSE pendant la montée jusqu'au maximum d'entrée (°C) | 0,3045 | 0,1667 |
| RMSE après ce maximum, pendant la descente (°C) | 0,3765 | 0,3315 |

L'ajout paroi–pertes réduit la RMSE d'environ 32 % et la MAE d'environ 45 %, mais augmente le maximum d'environ 13 %. Il ne domine donc pas tous les critères. Il réduit le biais d'une grande partie de l'essai, sans résoudre le décalage autour du changement de tendance.

Un contrôle de sensibilité à l'initialisation examine aussi la partie après 1305,83 s, soit trois constantes de temps calculées avec la capacité eau+paroi et le débit du banc : RMSE 0,3302 °C pour A et 0,2199 °C pour B. La conclusion moyenne ne dépend donc pas de l'inclusion du début. Cette durée est une règle exploratoire calculée, pas une durée de stabilisation mesurée ou une exigence du projet.

Le raffinement du pas maximal de 1 à 0,5 s change la température calculée de A d'au plus 6,35e-6 °C aux instants mesurés. L'erreur numérique temporelle est négligeable face aux écarts expérimentaux observés sur ce test. Ce constat ne constitue pas à lui seul une validation physique.

## 4. Contrôle sur quatre essais plus rapides
Chaque ligne utilise le même banc, ses entrées mesurées et les mêmes paramètres physiques ; aucun recalage par essai.
| Jeu | RMSE A (°C) | RMSE B (°C) | Maximum A (°C) | Maximum B (°C) |
|---|---:|---:|---:|---:|
| 151202 | 7,5677 | 6,9126 | 19,5036 | 16,4348 |
| 151204_1 | 2,6249 | 2,3406 | 8,3556 | 7,0090 |
| 151204_4 | 4,7619 | 4,2195 | 17,2229 | 14,3449 |
| 160118_1 | 2,9392 | 2,5410 | 10,9218 | 9,2227 |

Le jeu 151204_4 présente aussi une initialisation spatiale incertaine, avec 31,2 °C à l'entrée contre 27,7 °C à la sortie. Les grands écarts des autres essais ne dépendent pas de ce seul jeu. La capacité de la paroi et les pertes améliorent certaines erreurs mais ne corrigent pas le manque de délai de propagation d'un volume parfaitement mélangé.

## 5. Ce que cela change pour le projet
1. Une justification expérimentale du 0D existe maintenant pour un vrai transitoire lent, avec augmentation et diminution notables de température.
2. Ce résultat est limité à un essai, une géométrie et un débit ; il ne définit pas une frontière universelle entre « lent » et « rapide ».
3. Pour les volumes de 3 L du projet, le temps de passage de 30–43 s reste un indicateur utile, mais on ne peut pas transposer directement la RMSE du banc de 84 L à la boucle proposée. Il faut également considérer l'amplitude des variations, les pertes et l'inertie de la paroi.
4. Pour un prototype centré sur la surveillance de dérives lentes de capteurs, le 0D est une base défendable et moins complexe. Les phases de démarrage ne peuvent être écartées de l'évaluation que si le domaine et les règles d'activation du diagnostic le prévoient explicitement.
5. L'adaptation B conserve le caractère 0D et le nombre de volumes. Elle est une candidate si la géométrie et l'isolation du projet sont définies ; ajouter ces paramètres sans les justifier ne renforcerait pas la preuve. Elle ne doit pas être présentée comme une solution aux transitoires rapides.
6. Si la fidélité pendant les démarrages ou changements rapides fait partie des exigences, il faut réadapter le transport des conduites : délai physique explicite ou représentation distribuée. Un réseau comportant davantage de volumes doit être décrit comme un changement de granularité ; un maillage axial est une représentation spatiale et ne doit pas être renommé « 0D initial ».
7. Les essais portent seulement sur la thermique d'une conduite. Ils ne valident ni les coefficients hydrauliques choisis, ni l'échangeur, ni les cinq volumes couplés. Une campagne de boucle complète reste nécessaire pour ces affirmations.
8. L'écart SS1–SS3 en fonctionnement sain et la condition C1 du rapport de concepts doivent être testés séparément. Une RMSE expérimentale de 0,32 °C n'est pas directement comparable à une condition exprimée en fraction de l'écart type du résidu. L'indépendance du modèle de référence et les fausses alarmes restent à vérifier.

## 6. Verdict proposé
Conserver le concept 0D comme base du prototype pour les scénarios thermiques lents et documenter son domaine. Ne pas revenir automatiquement au modèle hybride plus lourd sur la seule base des essais rapides, puisque le besoin pédagogique vise d'abord la surveillance et les dérives lentes. À l'inverse, ne pas déclarer le 0D validé pour tous les scénarios. L'ajout paroi–pertes est une amélioration physique possible à examiner selon les critères d'erreur moyenne et maximale ; son gain sur un essai ne suffit pas à imposer ce choix. Si les exigences incluent les transitoires rapides représentatifs, le découpage ou la méthode de transport devra changer.

Le meilleur concept au sens de la matrice ne peut pas être recalculé sans pondérations et limites d'erreur adoptées pour ce domaine : les résultats ci-dessus fournissent désormais des preuves pour discuter le choix. Aucun seuil de 1 °C, de 5 % ou autre n'a été introduit comme critère officiel de réussite après observation des résultats.

## 7. Texte pour le rapport
Le modèle 0D de conduite a été confronté aux mesures de l'essai PipeDataULg160104_2 de l'Université de Liège. Cet essai couvre une augmentation progressive de la température d'entrée jusqu'à 34,7 °C, puis une diminution jusqu'à 21,1 °C, sur environ 170 minutes. Sans recalage des paramètres sur la sortie mesurée, la représentation initiale obtient une erreur quadratique moyenne de 0,32 °C et un écart maximal de 0,84 °C sur l'essai complet. L'ajout de la capacité thermique de la paroi et des pertes réduit l'erreur quadratique moyenne à 0,22 °C, avec un écart maximal de 0,94 °C. Ces comparaisons soutiennent le concept à paramètres concentrés pour des évolutions lentes, sans démontrer sa précision sur l'ensemble de la boucle proposée. Les erreurs nettement supérieures sur les essais plus rapides conduisent à limiter son domaine ou à adapter explicitement la représentation du transport thermique si ces transitoires font partie des exigences. Les critères de réception doivent être fixés en fonction de l'usage attendu.

## Reproduire et vérifier
Installer numpy, scipy, matplotlib, puis exécuter `python essais.py` dans ce dossier. Les données expérimentales originales .mos, les sorties CSV, les résultats JSON et la figure sont inclus. Les versions utilisées sont dans resultats.json ; les empreintes des fichiers sources sont dans provenance.json. Les figures sont des calculs réalisés ici, pas des figures des auteurs. La publication est citée pour les expériences et leurs conditions, sans attribuer nos scores à son modèle.
