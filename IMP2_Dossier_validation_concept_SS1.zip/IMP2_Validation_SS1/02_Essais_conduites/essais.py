"""Essais thermiques sur mesures ULg. Aucun recalage des paramètres.
pip install numpy scipy matplotlib
python essais.py
"""
from pathlib import Path
import json, platform
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.sparse import lil_matrix
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
L=39.; DI=.05248; DO=.0603
V=np.pi*DI**2/4*L
CW=1000*V*4180
CS=7800*np.pi*(DO**2-DI**2)/4*L*480
UA=2*np.pi*L/(np.log((DO+.026)/DO)/.04+2/(5*(DO+.026)))
CASES=['151202','151204_1','151204_4','160118_1','160104_2']
RESULT={}

def metrics(a,p,mask):
    e=p[mask]-a[mask,3]
    return dict(n=int(mask.sum()),RMSE_C=float(np.sqrt(np.mean(e**2))),MAE_C=float(np.mean(abs(e))),max_abs_C=float(abs(e).max()))

for name in CASES:
    a=np.loadtxt(ROOT/('PipeDataULg'+name+'.mos'),delimiter=',',skiprows=2)
    t=a[:,0]
    predictions={}
    result={'duree_s':float(t[-1]),'n':len(t),'debit_kg_s':float(a[0,1]),'Tin_debut_C':float(a[0,5]),'Tin_fin_C':float(a[-1,5]),'Tin_max_C':float(max(a[:,5]))}
    peak=t[np.argmax(a[:,5])]
    warmup=3*(CW+CS)/(a[0,1]*4180)
    masks={'complet':np.ones(len(t),bool)}
    if name=='160104_2':
        masks.update(apres_initialisation=t>=warmup,montee=t<=peak,descente=t>peak)
        result['fin_initialisation_exploratoire_s']=float(warmup)
    for label,C,loss in [('0D_initial',CW,0.),('0D_paroi_pertes',CW+CS,UA)]:
        def fun(ts,y):
            md=np.interp(ts,t,a[:,1]); ti=np.interp(ts,t,a[:,5])
            return [(md*4180*(ti-y[0])-loss*(y[0]-18))/C]
        sol=solve_ivp(fun,[0,t[-1]],[a[0,3]],t_eval=t,rtol=1e-8,atol=1e-9,max_step=1.)
        assert sol.success
        predictions[label]=sol.y[0]
        result[label]={part:metrics(a,sol.y[0],mask) for part,mask in masks.items()}
    RESULT[name]=result
    np.savetxt(ROOT/('comparaison_'+name+'.csv'),np.c_[t,a[:,5],a[:,3],predictions['0D_initial'],predictions['0D_paroi_pertes']],delimiter=',',header='temps_s,entree_mesuree_C,sortie_mesuree_C,0D_initial_C,0D_paroi_pertes_C',comments='')
    if name=='160104_2':
        fig,ax=plt.subplots(2,1,figsize=(10,6),sharex=True,layout='constrained')
        ax[0].plot(t/60,a[:,5],':',color='.5',label='Entrée mesurée')
        ax[0].plot(t/60,a[:,3],color='black',label='Sortie mesurée')
        for k,p in predictions.items():
            ax[0].plot(t/60,p,label=k.replace('_',' '))
            ax[1].plot(t/60,p-a[:,3],label=k.replace('_',' '))
        ax[0].set_ylabel('Température (°C)');ax[0].legend(fontsize=8)
        ax[1].axhline(0,color='black',linewidth=.7)
        ax[1].set(xlabel='Temps (min)',ylabel='Calcul − mesure (°C)')
        for axis in ax:axis.grid(alpha=.2)
        fig.savefig(ROOT/'essai_lent.png',dpi=180)
        plt.close(fig)

# Contrôle de convergence temporelle du cas lent initial, sans changer le modèle.
a=np.loadtxt(ROOT/'PipeDataULg160104_2.mos',delimiter=',',skiprows=2)
def slow_fun(ts,y):
    return [np.interp(ts,a[:,0],a[:,1])*4180*(np.interp(ts,a[:,0],a[:,5])-y[0])/CW]
s1=solve_ivp(slow_fun,[0,a[-1,0]],[a[0,3]],t_eval=a[:,0],max_step=1.,rtol=1e-8,atol=1e-9)
s2=solve_ivp(slow_fun,[0,a[-1,0]],[a[0,3]],t_eval=a[:,0],max_step=.5,rtol=1e-9,atol=1e-10)
RESULT['verification_pas_max_1_vs_0_5_s_C']=float(max(abs(s1.y[0]-s2.y[0])))
RESULT['versions']={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__}
RESULT['parametres']={'V_m3':V,'C_eau_J_K':CW,'C_paroi_J_K':CS,'UA_W_K':UA,'Tamb_C':18}
(ROOT/'resultats.json').write_text(json.dumps(RESULT,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(RESULT,ensure_ascii=False,indent=2))
