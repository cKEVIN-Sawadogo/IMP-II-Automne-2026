"""Comparaison préliminaire 0D : données de figure, pas données brutes.
Exécution : python reproduire.py ; dépendances : numpy, matplotlib.
"""
from pathlib import Path
import json, platform
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
measures = np.loadtxt(ROOT/'mesures_reconstruites.csv', delimiter=',', skiprows=1)
steps = np.loadtxt(ROOT/'commandes_reconstruites.csv', delimiter=',', skiprows=1)
power = np.interp(steps[:,1], [4,7.5,9,11,14,17,20], [0,2240,2610,4650,8890,13600,15040])
V = .003309375
capacity = 991*V*4180
flow_capacity = 997.1*9.04e-5*4180

def simulate(times, volume_factor=1., flow_factor=1., delay=8.):
    """Solution exacte par intervalles à puissance constante, sans ajustement."""
    C = capacity*volume_factor
    F = flow_capacity*flow_factor
    at_step = [measures[0,1]]
    for k in range(len(steps)-1):
        equilibrium = 24 + power[k]/F
        at_step.append(equilibrium+(at_step[-1]-equilibrium)*np.exp(-F*(steps[k+1,0]-steps[k,0])/C))
    times = np.maximum(0, times-delay)
    k = np.maximum(0,np.searchsorted(steps[:,0],times,side='right')-1)
    equilibrium = 24+power[k]/F
    return equilibrium+(np.asarray(at_step)[k]-equilibrium)*np.exp(-F*(times-steps[k,0])/C)

t = np.arange(0,4001,5.)
measured = np.interp(t,measures[:,0],measures[:,1])
predicted = simulate(t)
def metrics(pred):
    error = pred-measured
    k = np.argmax(np.abs(error))
    return dict(RMSE_C=float(np.sqrt(np.mean(error**2))),MAE_C=float(np.mean(abs(error))),max_abs_C=float(abs(error[k])),temps_max_s=float(t[k]))

results = {'statut':'reconstruction preliminaire; aucun critere de reception adopte',
           'versions':{'python':platform.python_version(),'numpy':np.__version__,'matplotlib':matplotlib.__version__},
           'nominal':metrics(predicted),
           'sensibilite_exploratoire_non_metrologique':{
               'debit_moins_5pct':metrics(simulate(t,flow_factor=.95)),
               'debit_plus_5pct':metrics(simulate(t,flow_factor=1.05)),
               'volume_moins_10pct':metrics(simulate(t,volume_factor=.9)),
               'volume_plus_10pct':metrics(simulate(t,volume_factor=1.1)),
               'sans_retard_mesure':metrics(simulate(t,delay=0.))}}
(ROOT/'resultats.json').write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding='utf-8')
np.savetxt(ROOT/'comparaison.csv',np.column_stack([t,measured,predicted,predicted-measured]),delimiter=',',header='temps_s,temperature_mesuree_reconstruite_C,temperature_0D_C,erreur_C',comments='')
fig,ax=plt.subplots(2,1,figsize=(10,6),sharex=True,layout='constrained')
ax[0].plot(t,measured,color='.4',label='Mesures reconstruites — figure 3')
ax[0].plot(t,predicted,label='Bilan thermique 0D simplifié',linewidth=1.3)
ax[0].set_ylabel('Température (°C)');ax[0].legend()
ax[1].plot(t,predicted-measured);ax[1].axhline(0,color='black',linewidth=.7)
ax[1].set(xlabel='Temps (s)',ylabel='Calcul − mesure (°C)')
for a in ax:a.grid(alpha=.25)
fig.savefig(ROOT/'comparaison_reservoir.png',dpi=170)
fig,ax=plt.subplots(figsize=(9,4),layout='constrained')
for tau in [30.,3/.07]:
    ts=np.linspace(0,150,1501)
    ax.plot(ts,1-np.exp(-ts/tau),label=f'Volume homogène : τ = {tau:.1f} s')
    ax.plot([0,tau,tau,150],[0,0,1,1],'--',label=f'Transport idéal : délai = {tau:.1f} s')
ax.set(xlabel='Temps après un échelon à l’entrée (s)',ylabel='Variation de sortie / variation imposée',title='Comparaison théorique — aucune mesure expérimentale')
ax.grid(alpha=.25);ax.legend(fontsize=8)
fig.savefig(ROOT/'limite_conduites.png',dpi=170)
print(json.dumps(results,indent=2,ensure_ascii=False))
