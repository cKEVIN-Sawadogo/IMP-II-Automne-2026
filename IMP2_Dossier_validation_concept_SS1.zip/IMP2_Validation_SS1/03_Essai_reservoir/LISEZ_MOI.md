# IMP2 — Justification du concept SS1 à volumes homogènes

## Verdict
Le bilan thermique 0D d'un réservoir agité est soutenu par une comparaison expérimentale préliminaire. La boucle complète à cinq volumes n'est pas encore validée physiquement. En particulier, représenter chaque conduite par un seul volume homogène reste une hypothèse à vérifier pour les transitoires retenus. Le modèle 0D reste le concept prioritaire ; aucune substitution par un modèle 1D n'est effectuée ici.

## 1. Réservoir : source et traçabilité
Source principale : Thornhill, N. F., Patwardhan, S. C. et Shah, S. L. (2008), A continuous stirred tank heater simulation model with applications, Journal of Process Control 18, 347–360. DOI : https://doi.org/10.1016/j.jprocont.2007.07.006 . Dépôt des auteurs : https://spiral.imperial.ac.uk/entities/publication/906cd609-2de3-418b-b68c-60f2fd965331 . Modèles associés : https://zenodo.org/records/10093059 .

Repères à consulter : équations et caractérisation thermique p. 350 ; étalonnages p. 351–352 ; essai thermique ouvert et figure 3 p. 353. Les courbes grises de cette figure correspondent aux mesures, les noires à la simulation des auteurs. Notre calcul est distinct de leur simulation.

Les CSV de ce dossier reconstruisent les tracés vectoriels du PDF publié, et non les acquisitions brutes. Extraction par PyMuPDF, page PDF d'indice 6 : tracés gris 183–185 pour la température, tracés 87–89 pour les commandes. Ces indices ne valent que pour le PDF du dépôt utilisé. Coordonnées temporelles : x=154.59300231933594 pour 0 s, x=285.9739990234375 pour 4000 s. Conversion du signal thermique : y=691.2569580078125 pour 8 mA, y=624.02099609375 pour 14 mA. Les points de même abscisse sont moyennés. La commande est reconstruite par paliers arrondis à 0,5 mA. La précision graphique n'est pas l'incertitude du capteur.

Le signal thermique est converti par interpolation avec les points T (°C) = [24,30,31,36.5,44.5,48,61,65] et signal (mA) = [7.785,8.61,8.76,9.59,10.8,11.38,13.52,14.2], repris du modèle associé à l'étude.

## 2. Calcul reproduit
Équation simplifiée : C dT/dt = P(t) + F(24 − T), avec C = rho_stockage V cp et F = rho_entree q cp. Un seul état thermique ; aucune discrétisation spatiale. Solution analytique par intervalles à puissance constante, échantillonnée toutes les 5 s sur 0–4000 s pour comparer les courbes sans surpondérer les zones riches en sommets graphiques.

Paramètres et statuts :
- Niveau 20,48 cm : explicitement donné pour l'essai p. 353.
- Volume 3,309375 L : interpolation de la relation volume–niveau du modèle fourni ; ce n'est pas la capacité maximale de la cuve.
- Débit q = 9,04e-5 m³/s : valeur de caractérisation p. 350, cohérente avec l'ordre de grandeur de l'écoulement sortant à ce niveau ; absence de série synchronisée avec la figure 3. Débit supposé constant dans notre reproduction, et non mesuré à chaque instant.
- Entrée à 24 °C : condition de base publiée, supposée applicable à l'essai reconstruit ; fluctuations non disponibles.
- cp = 4180 J/(kg K) constant ; rho_stockage = 991 kg/m³ constant, approximation représentative ; rho_entree = 997,1 kg/m³. Ce choix constant n'est pas la formulation complète à enthalpie variable des auteurs. Aucun paramètre n'est optimisé sur la courbe transitoire.
- Puissance : interpolation des paliers du tableau 1, p. 350, aux commandes reconstruites. L'étalonnage expérimental de puissance limite l'indépendance des résultats stabilisés.
- Température initiale : première valeur reconstruite, environ 28,84 °C.
- Retard de sortie de 8 s : somme des deux retards de mesure du fichier CSTHMaster.mdl, 0,5 et 7,5 s ; ce n'est pas un état spatial du procédé. Les valeurs antérieures à zéro sont maintenues à la température initiale.

Hypothèses : eau liquide, mélange parfait, capacité thermique fixe, alimentation froide seule, pertes thermiques et dynamique propre de la vanne non explicitées. Le maintien du niveau ne signifie pas qu'une température est régulée pendant cet essai.

## 3. Résultats obtenus
Sur l'ensemble des 801 instants communs : RMSE = 0,8274 °C ; MAE = 0,5594 °C ; écart absolu maximal = 4,1808 °C à 2270 s. Aucun intervalle défavorable n'a été supprimé. L'erreur maximale survient après une diminution de commande ; sa cause ne peut être attribuée avec certitude à un seul mécanisme. L'article signale une asymétrie de fonctionnement de la vanne à la fermeture.

Sensibilité exploratoire, sans recalage des autres paramètres : débit −5 % : RMSE 1,3903 °C ; débit +5 % : 1,4957 °C ; volume −10 % : 0,8436 °C ; volume +10 % : 0,8285 °C ; suppression du retard de mesure : 0,9031 °C. Les variations ±5 % et ±10 % sont des scénarios d'exploration choisis ici, pas des incertitudes instrumentales publiées. Elles montrent pourquoi confirmer le débit importe avant de conclure à une précision donnée.

Interprétation : le modèle retrouve l'essentiel de l'évolution thermique reconstruite. Aucun seuil de réception du projet n'étant adopté pour cette comparaison, il serait incorrect d'écrire « validation réussie » sur le seul fondement de RMSE < 1 °C. La dépendance aux étalonnages et les conditions non synchronisées doivent figurer avec les chiffres.

## 4. Conduites du SS1 : vérification de l'hypothèse
Le document IMP2_Section_2_1_SS1.docx prévoit 3 L pour chacune des conduites V2 et V4 et pour V5. Avec rho=1000 kg/m³, le débit de 0,100 kg/s correspond à 0,100 L/s, celui de 0,070 kg/s à 0,070 L/s. Le temps V/q vaut donc 30 s ou 42,86 s pour chacun de ces volumes.

Comparaison théorique, sans donnée expérimentale : une conduite idéale sans dispersion ni pertes transmet une variation d'entrée avec un délai tau. Un volume parfaitement mélangé suit tau dTsortie/dt + Tsortie = Tentree. Après un échelon unitaire, sa sortie vaut 1−exp(−t/tau), au lieu d'un échelon retardé. Juste avant tau, la première réponse atteint déjà 63,2 % de la variation, tandis que la seconde n'a pas changé. Pour une variation de 1 °C, cela représente environ 0,632 °C d'écart dans cette comparaison idéale. Ce chiffre n'est pas l'erreur mesurée de votre conduite réelle.

Conséquence : cette approximation peut convenir aux évolutions lentes ou à l'équilibre, mais sa précision pour les changements rapides n'est pas acquise. Un écoulement turbulent ne démontre pas à lui seul un mélange axial parfait sur toute la longueur.

Repère analytique supplémentaire, pas critère expérimental : pour une entrée sinusoïdale, le gain du volume mélangé vaut 1/sqrt(1+(omega*tau)^2), celui du transport idéal vaut 1. Limiter uniquement cet écart d'amplitude à 5 % exige une période d'environ 19,1 tau, soit 574 s au débit nominal ou 819 s à 70 %. Cela ne garantit ni une erreur totale de 5 %, ni la représentativité d'une conduite avec paroi et pertes.

## 5. Décisions pour le rapport
1. Conserver le concept 0D, en qualifiant la comparaison du réservoir d'appui expérimental préliminaire.
2. Séparer les paramètres proposés du SS1 (20 L, 1000 W, UA=100 W/K et courbes hydrauliques choisies) des paramètres du banc expérimental. Ceux du SS1 ne deviennent pas validés par cette comparaison.
3. Définir les amplitudes, vitesses de variation et erreurs admissibles des scénarios avant d'accepter l'approximation des conduites. Les tests de détection des dérives de capteur ne suffisent pas à valider la physique de SS1.
4. Comparer ensuite le bilan 0D de conduite à un essai réel dont température d'entrée, température de sortie, débit et géométrie sont connus, sans ajuster les paramètres sur le même essai utilisé pour conclure. Les essais d'étalonnage et ceux de validation doivent être distingués.
5. Si cette comparaison échoue pour les scénarios requis, documenter l'échec et réexaminer le découpage ou le domaine de validité. Un changement du nombre de volumes doit être explicite ; ne pas présenter un maillage 1D comme le concept initial à cinq volumes.
6. Pour pression et débit, employer une courbe de pompe et des pertes de charge issues de mesures ou d'une caractérisation physique traçable. Les coefficients A, B et R actuellement choisis pour obtenir 6 L/min ne constituent pas une preuve expérimentale.

## 6. Paragraphe utilisable dans le rapport
Le concept à paramètres concentrés est conservé pour la conception préliminaire. Une comparaison avec la réponse expérimentale publiée d'un réservoir agité apporte un premier appui au bilan thermique 0D. La reconstruction de cet essai donne une erreur quadratique moyenne de 0,83 °C et un écart maximal de 4,18 °C. Ces résultats sont préliminaires : les mesures ont été extraites d'une figure et certaines conditions sont reprises des valeurs de caractérisation plutôt que d'acquisitions synchronisées. Ils ne valident pas l'ensemble de la boucle SS1. Pour les volumes de conduite de 3 L, le temps de passage calculé varie de 30 à 43 s sur les deux débits étudiés ; l'hypothèse de mélange parfait devra donc être confrontée à un essai de transport thermique dans le domaine temporel visé. La validation hydraulique reste à réaliser séparément. Les bilans de conservation et les essais de convergence déjà exécutés constituent des vérifications numériques complémentaires.

## Reproduire
Depuis ce dossier : `python -m pip install numpy matplotlib`, puis `python reproduire.py`. Le programme régénère les figures, comparaison.csv et resultats.json. Les versions effectivement utilisées sont consignées dans resultats.json. Aucun logiciel commercial ni téléchargement du PDF n'est nécessaire pour relancer les calculs à partir des données reconstruites incluses. Le PDF original n'est pas redistribué.
