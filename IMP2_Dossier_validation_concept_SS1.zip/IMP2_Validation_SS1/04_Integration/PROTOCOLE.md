# Validation de la chaîne SS1 SS2 SS3 SS4

Ce protocole n'est pas un résultat d'essai. Aucun résultat C1, temps réel, endurance ou détection n'est déclaré acquis dans ce dossier.

## 1. Configuration avant essais
Identifier les versions de SS1, SS2, SS3 et SS4, le pas d'acquisition (1 s proposé), les unités, le domaine thermique autorisé et les scénarios. Consigner les puissances, vitesses et températures initiales. Fixer une valeur et une métrique pour les tolérances proposées dans le rapport de concepts p. 25 : 2–3 °C, 0,1–0,2 MPa et 2–3 % du débit. L'essai lent de conduite permet seulement une comparaison indicative au seuil thermique : il ne valide pas les deux autres tolérances.

La dérive lente du capteur n'impose pas une dynamique lente du procédé. Définir les variations autorisées de chauffage et de pompe, ainsi que le traitement du démarrage. Ne pas retirer après coup les phases qui déclenchent des alarmes. Toute exclusion doit être annoncée dans le domaine et les règles d'activation du diagnostic.

## 2. Vérifier SS1 et son interface
Exécuter 01_Modele_0D/simuler_ss1_0d.py ; contrôler bilans, étude de pas et trajectoires. Puis tester 100 cycles consécutifs de la chaîne : trois sorties T/P/Q présentes, unités constantes, horodatage et numéro de cycle cohérents. Vérifier que SS2 ne modifie pas les grandeurs vraies de SS1. La répétition à configuration et graine identiques doit reproduire les mêmes données, avec les versions de calcul figées.

## 3. Caler SS3 et SS4 sans fuite d'information
Choisir un jeu d'essais sains réservé au calage. SS3 est réduit et indépendant : seules les mesures SS2 et les entrées autorisées par le contrat lui sont accessibles ; jamais les paramètres ni les grandeurs vraies SS1. Estimer les paramètres SS3, le biais de centrage et sigma du résidu sain. Figer ces valeurs avant la validation. Ne pas recaler en ligne la référence en boucle ouverte. Une simple soustraction du biais réestimé sur les essais de validation annulerait artificiellement le critère C1.

## 4. Tester C1 sur 20 à 30 essais sains distincts
Conserver des graines et des essais différents de ceux du calage, couvrant les conditions autorisées. Pour T, P et Q, calculer le résidu centré en conservant les paramètres figés, puis son biais résiduel et l'intervalle de confiance à 95 %. La condition annoncée est un biais résiduel au plus égal à 0,1 sigma. Une règle opérationnelle prudente consiste à exiger que l'intervalle du biais soit entièrement compris entre −0,1 sigma et +0,1 sigma ; faire confirmer cette interprétation par l'équipe avant exécution. Tenir compte de la corrélation temporelle : les cycles voisins ne sont pas automatiquement des observations indépendantes. Les moyennes d'essais indépendants constituent des unités statistiques possibles, en documentant la méthode et les différences de régime. Ne pas masquer un biais local par une moyenne entre régimes de signes opposés.

## 5. Vérifier le diagnostic et le temps réel
- Fonctionnement normal : 7200 cycles sur 120 min en temps horloge ; au plus une fausse alarme. Une simulation accélérée de 7200 s ne démontre pas l'endurance en temps horloge.
- Dérive de référence : pente 0,01 sigma par cycle, début à 600 s, amplitude plafonnée selon la configuration du capteur ; mesurer le délai après le début de la dérive. Moyenne ≤90 s et 95e centile ≤120 s, sur plusieurs essais. Documenter l'estimation du centile et le nombre d'essais.
- Dérive très lente 0,001 sigma/cycle et bruit triplé : essais des limites du détecteur ; ne pas annoncer les mêmes critères comme acquis.
- Saut franc de 6 sigma : vérifier l'état anomalie et la règle d'ordre avec la somme cumulée.
- Coupure de communication et valeur hors plage : état incertain, rejet et journalisation. Le document contient une ambiguïté à harmoniser : « plus de N=3 cycles » p. 15, contre « au troisième cycle » p. 26. Fixer la convention avant de tester.
- Chronométrer la chaîne complète : cycle <1 s ; marge interne proposée de 0,5 s au 99e centile. Les temps d'exécution des scripts autonomes ne sont pas cette mesure.

## 6. Décision prévue
Si C1 échoue malgré le calage autorisé, le rapport de concepts p. 23 prévoit d'abord une révision de SS3 vers la référence recalée, avec vérification que la dérive n'est pas absorbée. Cela n'impose pas automatiquement un SS1 en 1D. Si les exigences incluent des défaillances localisées du procédé ou des transitoires thermiques rapides représentatifs, réexaminer la modélisation du transport dans SS1. Toute modification est consignée, avec ses conséquences sur les autres modules.

La fiche résultats_a_completer.csv est volontairement sans mesures. Le statut initial est NON_EXECUTE, jamais CONFORME par défaut.

## 7. Justification préliminaire ajoutée
Exécuter 01_Modele_0D/justifier_parametres.py pour les ordres de grandeur et sensibilités. Ce calcul justifie la cohérence du scénario, sans identifier une pompe ou un échangeur réels. La comparaison à des caractéristiques mesurées ou constructeur reste à effectuer. Le report de travaux de caractérisation ne modifie pas les échéances C1 et essais de chaîne prévues au rapport de concepts.
