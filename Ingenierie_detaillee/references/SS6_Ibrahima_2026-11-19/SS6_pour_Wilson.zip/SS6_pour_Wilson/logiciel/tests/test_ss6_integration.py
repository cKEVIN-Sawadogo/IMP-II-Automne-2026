"""Contrat SS-6, cache partagé et commande de vérification."""
import os
import json
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

from jumeau.etat_partage import CacheEtat
from jumeau.orchestrateur import Orchestrateur
from jumeau.scenario import charger
from jumeau.ss6_journal import JournalDonnees, verifier

RACINE = Path(__file__).resolve().parents[1]


def test_sortie_ss6_et_rechargement_cache(tmp_path):
    journal = JournalDonnees()
    journal.demarrer({"sortie": tmp_path})
    try:
        for k in range(5):
            sortie = journal.etape(k, {"contenu": {"k": k}})
            assert set(sortie) == {"sequence", "empreinte"}
            assert len(sortie["empreinte"]) == 64
        cache = CacheEtat()
        assert cache.recharger_depuis_journal(tmp_path / "journal.sqlite") == 5
        assert cache.dernier()["empreinte"] == sortie["empreinte"]
    finally:
        journal.arreter()
    assert verifier(tmp_path, cycles_attendus=5).integre


def test_cycle_duplique_refuse(tmp_path):
    journal = JournalDonnees()
    journal.demarrer({"sortie": tmp_path})
    try:
        journal.etape(0, {"contenu": {"k": 0}})
        with pytest.raises(ValueError):
            journal.etape(0, {"contenu": {"k": 0}})
    finally:
        journal.arreter()


def test_cycle_sql_modifie_detecte(tmp_path):
    journal = JournalDonnees()
    journal.demarrer({"sortie": tmp_path})
    journal.etape(0, {"contenu": {"k": 0}})
    journal.arreter()
    with sqlite3.connect(tmp_path / "journal.sqlite") as cx:
        cx.execute("UPDATE journal SET k = 7")
    assert not verifier(tmp_path).integre


def test_chaine_complete_et_commande_verification(tmp_path):
    sortie = tmp_path / "essai"
    orch = Orchestrateur(
        charger(RACINE / "scenarios/nominal.json"), sortie, silencieux=True
    )
    orch.executer(100)
    assert verifier(sortie, cycles_attendus=100).integre
    assert len(orch.cache.dernier()["empreinte"]) == 64
    assert (sortie / "sceaux.sqlite").exists()
    with sqlite3.connect(sortie / "journal.sqlite") as cx:
        contenu = json.loads(cx.execute(
            "SELECT contenu FROM journal WHERE sequence=0"
        ).fetchone()[0])
    assert contenu["k"] == 0
    commande = [
        sys.executable, str(RACINE / "lancer.py"),
        "--verifier", str(sortie / "journal.sqlite"),
    ]
    resultat = subprocess.run(commande, capture_output=True, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
    assert resultat.returncode == 0, resultat.stderr
    assert "Verdict : INTÈGRE" in resultat.stdout.decode("utf-8")
    with sqlite3.connect(sortie / "sceaux.sqlite") as cx:
        cx.execute("DELETE FROM sceaux WHERE final=1")
    assert subprocess.run(commande, capture_output=True, env={**os.environ, "PYTHONIOENCODING": "utf-8"}).returncode == 1
