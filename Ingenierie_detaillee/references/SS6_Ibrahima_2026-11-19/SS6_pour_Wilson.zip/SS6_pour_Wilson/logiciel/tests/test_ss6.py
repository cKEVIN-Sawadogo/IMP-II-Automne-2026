"""Tests de SS-6 avec les données de SS-1 (le modèle 0D d'Ibrahima).

On refait les essais E1 à E9 du tableau SS-6-3 du rapport 12, mais avec les
vraies données de la chaîne : à chaque cycle, SimulateurBoucle (SS-1) donne
T, P (en MPa) et Q. On ajoute un peu de bruit à la place de SS-2, on tire un
état au hasard à la place de SS-4, puis on donne le tout à SS-6 comme le fait
l'orchestrateur.

    pytest tests/test_ss6.py     version rapide (1 graine, 3 arrêts brutaux)
    python tests/test_ss6.py     campagne complète du rapport (5 graines,
                                 10 arrêts brutaux, 36 000 cycles) : affiche
                                 le tableau SS-6-3 et la figure SS-6-2
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import shutil
import sqlite3
import statistics
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

# Pour pouvoir lancer « python tests/test_ss6.py » depuis la racine du projet.
RACINE = Path(__file__).resolve().parents[1]
if str(RACINE) not in sys.path:
    sys.path.insert(0, str(RACINE))

import pytest

from jumeau.contrat import Etat, Statut, Variable
from jumeau.ss1_boucle import SimulateurBoucle
from jumeau.ss1_boucle.modele_0d import matrices, regime_etabli
from jumeau.ss6_journal import JournalDonnees, verifier, verifier_journal
from jumeau.ss6_journal.ecrivain import EMPREINTE_DEPART, canonique, empreinte
from jumeau.ss6_journal.scelleur import message_sceau

CONSIGNES = {"vitesse_pompe": 1.0, "puissance_W": 1000.0}   # consignes nominales
BRUIT = {Variable.T: 0.05, Variable.P: 0.0002, Variable.Q: 0.0005}   # en °C, MPa et kg/s
CYCLES = 7200        # 120 minutes à 1 cycle par seconde
FIN_CALAGE = 600     # SS-3 est prêt après 600 cycles
GRAINES = [2026, 2027, 2028, 2029, 2030]
DEBUT = datetime(2026, 11, 20, 13, 0, tzinfo=timezone.utc)


# ---------------------------------------------------------------------------
# Données de l'essai
# ---------------------------------------------------------------------------

def cycles_essai(graine, nb_cycles):
    """Donne, cycle par cycle, le contenu que l'orchestrateur envoie à SS-6.

    Les grandeurs vraies de SS-1 ne vont jamais au journal : on n'y met que
    les mesures bruitées (tableau 7-1).
    """
    ss1 = SimulateurBoucle()
    ss1.demarrer({"scenario": {"consignes_initiales": CONSIGNES}})

    # Valeurs attendues en régime établi, pour calculer les résidus
    _, _, debit, pression = matrices(CONSIGNES["vitesse_pompe"], CONSIGNES["puissance_W"])
    temperatures = regime_etabli(CONSIGNES["vitesse_pompe"], CONSIGNES["puissance_W"])
    attendus = {Variable.T: float(temperatures[0]), Variable.P: float(pression), Variable.Q: float(debit)}

    alea = random.Random(graine)
    etat = Etat.INCERTAIN   # on suppose « incertain » tant que SS-3 n'est pas calé

    for k in range(nb_cycles):
        vraies = ss1.etape(k, {"consignes": CONSIGNES})["grandeurs_vraies"]

        mesures = []
        residus = {}
        evenements = []
        for v in Variable:
            if alea.random() < 0.001:
                # De temps en temps, une mesure perdue (comme SS-2 le fait)
                mesures.append({"variable": v, "valeur": None, "statut": Statut.ABSENT})
                residus[v] = None
                evenements.append({"type": "mesure_rejetee", "variable": v, "motif": "format_invalide"})
            else:
                valeur = vraies[v] + alea.gauss(0.0, BRUIT[v])
                mesures.append({"variable": v, "valeur": valeur, "statut": Statut.VALIDE})
                residus[v] = (valeur - attendus[v]) / BRUIT[v]

        # Changement d'état : à la fin du calage, puis au hasard (environ 1 fois sur 600)
        if k == FIN_CALAGE:
            etat = Etat.NORMAL
        elif k > FIN_CALAGE and alea.random() < 1 / 600:
            autres = [e for e in Etat if e is not etat]
            etat = alea.choice(autres)

        yield {
            "k": k,
            "horodatage_utc": (DEBUT + timedelta(seconds=k)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "etat": etat,
            "mesures": mesures,
            "residus": residus,
            "evenements": evenements,
        }


def lancer_essai(dossier, graine, nb_cycles=CYCLES):
    """Fait tourner SS-6 sur un essai.
    Renvoie la durée de chaque etape (en ms) et le nombre de changements d'état."""
    ss6 = JournalDonnees()
    ss6.demarrer({"sortie": dossier, "scenario": {"graine": graine, "consignes_initiales": CONSIGNES}})

    durees = []
    changements = 0
    etat_prec = None
    for k, contenu in enumerate(cycles_essai(graine, nb_cycles)):
        if etat_prec is not None and contenu["etat"] is not etat_prec:
            changements += 1
        etat_prec = contenu["etat"]

        debut = time.perf_counter()
        ss6.etape(k, {"contenu": contenu})
        durees.append((time.perf_counter() - debut) * 1000)

    ss6.arreter()
    return durees, changements


def lire_contenus(dossier):
    cx = sqlite3.connect(dossier / "journal.sqlite")
    lignes = cx.execute("SELECT contenu FROM journal ORDER BY sequence").fetchall()
    cx.close()
    return [json.loads(texte) for (texte,) in lignes]


# ---------------------------------------------------------------------------
# Les « tricheries » des essais E2 à E8
# ---------------------------------------------------------------------------

def copier(source, nom):
    """Copie un essai pour pouvoir le modifier sans toucher l'original."""
    cible = source.parent / nom
    shutil.copytree(source, cible)
    return cible


def modifier_temperature(dossier, seq, delta=0.5):
    """E2 : on change la température d'une ligne, sans toucher aux empreintes."""
    cx = sqlite3.connect(dossier / "journal.sqlite")
    (texte,) = cx.execute("SELECT contenu FROM journal WHERE sequence = ?", (seq,)).fetchone()
    contenu = json.loads(texte)
    for m in contenu["mesures"]:
        if m["variable"] == "T":
            if m["valeur"] is None:
                m["valeur"] = 32.39
            m["valeur"] += delta
    cx.execute("UPDATE journal SET contenu = ? WHERE sequence = ?", (canonique(contenu), seq))
    cx.commit()
    cx.close()


def refaire_chaine(dossier):
    """E3 : le tricheur connaît SHA-256, il recalcule toutes les empreintes."""
    cx = sqlite3.connect(dossier / "journal.sqlite")
    lignes = cx.execute("SELECT sequence, contenu FROM journal ORDER BY sequence").fetchall()
    prec = EMPREINTE_DEPART
    for seq, contenu in lignes:
        h = empreinte(contenu, prec)
        cx.execute("UPDATE journal SET empreinte_precedente = ?, empreinte = ? WHERE sequence = ?", (prec, h, seq))
        prec = h
    cx.commit()
    cx.close()


def effacer_ligne(dossier, seq):
    cx = sqlite3.connect(dossier / "journal.sqlite")
    cx.execute("DELETE FROM journal WHERE sequence = ?", (seq,))
    cx.commit()
    cx.close()


def faux_sceaux(dossier):
    """E5 : on refait les sceaux sur la chaîne truquée, signés avec une autre clé."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    autre_cle = Ed25519PrivateKey.generate()

    cx = sqlite3.connect(dossier / "journal.sqlite")
    hashes = dict(cx.execute("SELECT sequence, empreinte FROM journal").fetchall())
    cx.close()

    cx = sqlite3.connect(dossier / "sceaux.sqlite")
    sceaux = cx.execute("SELECT numero, seq_debut, seq_fin, final, horodatage FROM sceaux").fetchall()
    for numero, debut, fin, final, heure in sceaux:
        emp = hashes.get(fin, EMPREINTE_DEPART)
        signature = autre_cle.sign(message_sceau(numero, debut, fin, emp, final, heure)).hex()
        cx.execute("UPDATE sceaux SET empreinte = ?, signature = ? WHERE numero = ?", (emp, signature, numero))
    cx.commit()
    cx.close()


def premier_changement(dossier):
    """Numéro du premier cycle qui porte une marque de changement d'état."""
    for contenu in lire_contenus(dossier):
        if "changement_etat" in contenu:
            return contenu["k"]
    return None


# ---------------------------------------------------------------------------
# Arrêt brutal (E6) : on tue le programme pendant qu'il écrit
# ---------------------------------------------------------------------------

def travailleur(dossier, graine):
    """Programme lancé à part par l'essai E6. Il écrit des cycles jusqu'à être tué."""
    ss6 = JournalDonnees()
    ss6.demarrer({"sortie": dossier, "scenario": {"graine": graine, "consignes_initiales": CONSIGNES}})
    print(ss6.pid_scelleur, flush=True)   # pour que l'essai sache quel scelleur attendre
    for k, contenu in enumerate(cycles_essai(graine, 10**7)):
        ss6.etape(k, {"contenu": contenu})
        time.sleep(0.001)


def processus_vivant(pid):
    if os.name == "nt":
        # Sous Windows, ne pas utiliser os.kill(pid, 0) comme test de présence.
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x00100000, False, pid)
        if not handle:
            return False
        try:
            return kernel.WaitForSingleObject(handle, 0) == 0x102
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    # Sous Linux, un processus « zombie » (Z) est déjà terminé
    try:
        etat = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[0]
        return etat != "Z"
    except OSError:
        return True


def arret_brutal(dossier, graine, duree_s):
    """Lance un essai dans un autre programme, le tue net après duree_s, puis vérifie."""
    env = os.environ.copy()
    env["PYTHONPATH"] = str(RACINE) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.Popen([sys.executable, __file__, "--travailleur", str(dossier), str(graine)],
                            stdout=subprocess.PIPE, text=True, env=env)
    pid_scelleur = int(proc.stdout.readline())

    time.sleep(duree_s)
    proc.kill()
    proc.wait()

    # Le scelleur finit les sceaux déjà demandés, puis s'arrête tout seul
    limite = time.monotonic() + 10
    while processus_vivant(pid_scelleur) and time.monotonic() < limite:
        time.sleep(0.05)

    r = verifier(dossier)
    if r.premiere_fautive is None:
        non_scellees = 0
    else:
        non_scellees = r.entrees - r.premiere_fautive
    # On ne doit trouver que ces deux problèmes-là, rien d'autre
    seulement_attendu = all(message.endswith("non scellées") or message == "sceau final absent (arrêt non contrôlé)"
                            for _, message in r.anomalies)
    return r, non_scellees, seulement_attendu


# ---------------------------------------------------------------------------
# Tests (pytest)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def essai_e1(tmp_path_factory):
    """Un essai complet de 7 200 cycles, réutilisé par les autres tests."""
    dossier = tmp_path_factory.mktemp("ss6") / "e1_2026"
    durees, changements = lancer_essai(dossier, 2026)
    return dossier, durees, changements


def test_les_donnees_de_ss1_arrivent_au_journal(tmp_path):
    """Essai d'interface sur 100 cycles avec SimulateurBoucle d'Ibrahima."""
    lancer_essai(tmp_path / "e", graine=1, nb_cycles=100)
    lignes = lire_contenus(tmp_path / "e")

    assert [c["k"] for c in lignes] == list(range(100))
    for c in lignes:
        assert [m["variable"] for m in c["mesures"]] == ["T", "P", "Q"]
        assert set(c["residus"]) == {"T", "P", "Q"}
        assert c["etat"] in [e.value for e in Etat]
        assert "grandeurs_vraies" not in c
        for m in c["mesures"]:
            # une mesure valide a une valeur, une mesure absente n'en a pas
            assert (m["statut"] == "valide") == (m["valeur"] is not None)

    # Les valeurs sont bien celles du modèle d'Ibrahima
    for variable, attendu in [("T", 32.39), ("P", 0.108), ("Q", 0.100)]:
        valeurs = [m["valeur"] for c in lignes for m in c["mesures"]
                   if m["variable"] == variable and m["valeur"] is not None]
        tolerance = 0.05 if variable == "T" else 0.001
        assert statistics.mean(valeurs) == pytest.approx(attendu, abs=tolerance)   # P en MPa, pas en kPa

    assert lignes[0]["evenements"][0]["type"] == "entete_essai"
    assert verifier_journal(tmp_path / "e") == (True, None, 100)


def test_e1_une_ligne_par_cycle_et_121_sceaux(essai_e1):
    dossier, _, _ = essai_e1
    r = verifier(dossier, cycles_attendus=CYCLES)
    assert r.integre, r.texte(None)
    assert r.entrees == 7200
    assert r.cycles == 7200
    assert r.sceaux == 121   # 7 200 / 60 = 120, plus le sceau final
    assert r.sceau_final


def test_e2_valeur_modifiee(essai_e1):
    d = copier(essai_e1[0], "e2_valeur")
    modifier_temperature(d, 3500)
    r = verifier(d)
    assert r.anomalies == [(3500, "seq 3500 : empreinte recalculée différente (contenu altéré)")]


def test_e3_chaine_refaite_les_sceaux_revelent_la_triche(essai_e1):
    d = copier(essai_e1[0], "e2_recalcul")
    modifier_temperature(d, 3500)
    refaire_chaine(d)
    r = verifier(d)
    assert r.sceaux_rejetes == 0
    assert len(r.anomalies) == 63   # sceaux 58 à 119, plus le final
    assert r.anomalies[0][1] == "sceau 58 : empreinte du bloc seq 3480-3539 ne correspond pas au journal"


def test_e4_ligne_effacee(essai_e1):
    d = copier(essai_e1[0], "e4_efface")
    effacer_ligne(d, 3500)
    r = verifier(d)
    assert r.anomalies[0] == (3500, "seq 3500 : entrée absente ou séquence rompue (lu seq 3501)")
    assert r.premiere_fautive == 3500


def test_e5_faux_sceaux_rejetes(essai_e1):
    d = copier(essai_e1[0], "e5_faux_sceaux")
    modifier_temperature(d, 3500)
    refaire_chaine(d)
    faux_sceaux(d)
    r = verifier(d)
    assert r.sceaux_rejetes == 121
    assert r.sceaux == 121


def test_e6_arret_brutal(tmp_path):
    alea = random.Random(6)
    for i in range(3):
        r, non_scellees, seulement_attendu = arret_brutal(tmp_path / f"e6_{i}", i, alea.uniform(0.8, 2.5))
        assert r.entrees > 0
        assert not r.sceau_final
        assert seulement_attendu, r.texte(None)
        assert non_scellees <= 60


def test_e7_chaque_changement_d_etat_a_sa_marque(essai_e1):
    dossier, _, changements = essai_e1
    r = verifier(dossier)
    assert changements > 0
    assert r.transitions == changements
    assert r.marques == changements


def test_e8_changement_d_etat_efface(essai_e1):
    d = copier(essai_e1[0], "e2_chg")
    k = premier_changement(d)
    effacer_ligne(d, k)   # une ligne par cycle, donc la ligne k est le cycle k
    r = verifier(d)
    assert r.premiere_fautive == k
    assert r.marques == essai_e1[2] - 1
    assert any("sans marque CHANGEMENT_ETAT" in message for _, message in r.anomalies)


def test_e9_ss6_ne_ralentit_pas_le_cycle(essai_e1):
    durees = essai_e1[1]
    depassements = [(k, ms) for k, ms in enumerate(durees) if ms >= 100]
    print(f"\nNombre de cycles : {len(durees)}")
    print(f"Médiane : {statistics.median(durees):.2f} ms")
    print(f"Maximum : {max(durees):.2f} ms")
    print(f"Cycles à au moins 100 ms : {len(depassements)}")
    print(f"Premiers dépassements (cycle, ms) : {depassements[:10]}")
    assert max(durees) < 100, (
        f"{len(depassements)} dépassement(s), maximum = {max(durees):.2f} ms"
    )


def test_un_seul_caractere_modifie_est_detecte(tmp_path):
    lancer_essai(tmp_path / "e", graine=3, nb_cycles=50)
    cx = sqlite3.connect(tmp_path / "e" / "journal.sqlite")
    cx.execute("UPDATE journal SET contenu = contenu || ' ' WHERE sequence = 20")
    cx.commit()
    cx.close()
    assert verifier_journal(tmp_path / "e" / "journal.sqlite") == (False, 20, 50)


def test_la_reponse_de_l_operateur_est_journalisee(tmp_path):
    """EX-F-09 : l'événement envoyé par SS-5 est gardé tel quel."""
    instantane = "[~] DÉRIVE  T=61.2 °C"
    reponse = {
        "type": "reponse_operateur",
        "reponse": "confirme",
        "demande_k": 1,
        "etat": Etat.DERIVE,
        "variables": [Variable.T],
        "severite": "non_critique",
        "instantane": instantane,
        "empreinte_instantane": hashlib.sha256(instantane.encode("utf-8")).hexdigest(),
    }
    ss6 = JournalDonnees()
    ss6.demarrer({"sortie": tmp_path / "e"})
    ss6.etape(1, {"contenu": {"k": 1, "etat": Etat.DERIVE, "evenements": []}})
    ss6.etape(2, {"contenu": {"k": 2, "etat": Etat.DERIVE, "evenements": [reponse]}})
    ss6.arreter()

    garde = lire_contenus(tmp_path / "e")[1]["evenements"][0]
    assert garde["etat"] == "derive"
    assert garde["variables"] == ["T"]
    assert garde["empreinte_instantane"] == hashlib.sha256(garde["instantane"].encode("utf-8")).hexdigest()
    assert verifier_journal(tmp_path / "e")[0]


def test_meme_graine_meme_journal(tmp_path):
    """EX-F-02 : même graine, mêmes lignes, donc mêmes empreintes."""
    lancer_essai(tmp_path / "a", graine=7, nb_cycles=200)
    lancer_essai(tmp_path / "b", graine=7, nb_cycles=200)
    hashes = []
    for nom in ["a", "b"]:
        cx = sqlite3.connect(tmp_path / nom / "journal.sqlite")
        hashes.append(cx.execute("SELECT empreinte FROM journal ORDER BY sequence").fetchall())
        cx.close()
    assert hashes[0] == hashes[1]


# ---------------------------------------------------------------------------
# Campagne complète du rapport : python tests/test_ss6.py
# ---------------------------------------------------------------------------

def fr(nombre, decimales=0):
    """Écrit un nombre à la française : 7 200 ou 0,04."""
    return f"{nombre:,.{decimales}f}".replace(",", " ").replace(".", ",")


def campagne(sortie):
    if sortie.exists():
        shutil.rmtree(sortie)
    sortie.mkdir(parents=True)
    tableau = []

    def noter(essai, resultat, reussi):
        verdict = "Réussi" if reussi else "ÉCHEC"
        tableau.append((essai, resultat, verdict))
        print(f"  {essai} : {resultat}", flush=True)

    print("Campagne SS-6 avec les données de SS-1 (Ibrahima)...")

    # E1 : 5 essais complets
    e1 = {}
    for graine in GRAINES:
        dossier = sortie / f"e1_{graine}"
        _, changements = lancer_essai(dossier, graine)
        e1[graine] = (dossier, changements, verifier(dossier, cycles_attendus=CYCLES))
    rapports = [r for _, _, r in e1.values()]
    tous_bons = all(r.integre and r.cycles == CYCLES and r.sceaux == 121 for r in rapports)
    noter("E1. Une ligne par cycle (EX-Q-02)",
          f"{fr(min(r.cycles for r in rapports))} sur {fr(CYCLES)} pour les {len(GRAINES)} graines ; "
          f"{rapports[0].sceaux} sceaux, dont le final", tous_bons)

    base = e1[2026][0]

    d = copier(base, "e2_valeur")
    modifier_temperature(d, 3500)
    r = verifier(d)
    noter("E2. Valeur modifiée", f"Ligne {fr(r.premiere_fautive)} signalée",
          r.anomalies == [(3500, "seq 3500 : empreinte recalculée différente (contenu altéré)")])

    d = copier(base, "e2_recalcul")
    modifier_temperature(d, 3500)
    refaire_chaine(d)
    r = verifier(d)
    noter("E3. Valeur modifiée et chaîne refaite",
          f"{len(r.anomalies)} sceaux sur {r.sceaux} ne correspondent plus, "
          f"à partir du bloc des lignes 3 480 à 3 539",
          len(r.anomalies) == 63 and r.premiere_fautive == 3480)

    d = copier(base, "e4_efface")
    effacer_ligne(d, 3500)
    r = verifier(d)
    noter("E4. Ligne effacée", f"Trou signalé à la ligne {fr(r.premiere_fautive)}", r.premiere_fautive == 3500)

    d = copier(base, "e5_faux_sceaux")
    modifier_temperature(d, 3500)
    refaire_chaine(d)
    faux_sceaux(d)
    r = verifier(d)
    noter("E5. Faux sceaux", f"{r.sceaux_rejetes} sceaux sur {r.sceaux} rejetés", r.sceaux_rejetes == r.sceaux)

    if sys.platform != "win32":
        alea = random.Random(6)
        resultats = []
        for i in range(1, 11):
            resultats.append(arret_brutal(sortie / f"e6_{i}", i, alea.uniform(0.8, 2.5)))
        reussis = [not r.sceau_final and seul and n <= 60 for r, n, seul in resultats]
        nombres = [n for _, n, _ in resultats]
        noter("E6. Arrêt brutal",
              f"{sum(reussis)} fois sur 10 ; {min(nombres)} à {max(nombres)} dernières lignes "
              f"signalées sans sceau ; rien d'autre", all(reussis))

    total = sum(changements for _, changements, _ in e1.values())
    marques = sum(r.marques for _, _, r in e1.values())
    transitions = sum(r.transitions for _, _, r in e1.values())
    noter("E7. Changements d'état (EX-F-10)", f"{total} changements, {marques} marques CHANGEMENT_ETAT",
          total == marques == transitions)

    d = copier(base, "e2_chg")
    k = premier_changement(d)
    effacer_ligne(d, k)
    r = verifier(d)
    noter("E8. Changement d'état effacé",
          f"Trou à la ligne {fr(k)} et changement d'état sans marque au cycle {fr(k + 1)}",
          r.premiere_fautive == k and any("sans marque" in m for _, m in r.anomalies))

    durees, _ = lancer_essai(sortie / "e9_rapidite", 2026, nb_cycles=36000)
    durees.sort()
    p99 = durees[int(0.99 * len(durees))]
    noter("E9. Rapidité (EX-Q-01)",
          f"{fr(statistics.mean(durees), 2)} ms en moyenne ; {fr(p99, 2)} ms dans 99 % des cas ; "
          f"{fr(durees[-1], 1)} ms au pire", durees[-1] < 100)

    # Tableau SS-6-3
    print("\nTableau SS-6-3. Essais de SS-6 avec les données de SS-1")
    largeur = max(len(essai) for essai, _, _ in tableau)
    for essai, resultat, verdict in tableau:
        print(f"{essai:<{largeur}}  {verdict:<7} {resultat}")

    # Figure SS-6-2
    print("\nFigure SS-6-2. Ce qu'affiche le vérificateur")
    for nom in ["e1_2026", "e2_valeur", "e2_recalcul", "e2_chg", "e6_3"]:
        if (sortie / nom).exists():
            print(f"\n$ python -m jumeau.ss6_journal {nom}/")
            print(verifier(sortie / nom).texte())

    print(f"\nJournaux gardés dans {sortie}/ (clés de test dans {sortie / 'cles_ss6'}/)")
    if all(verdict == "Réussi" for _, _, verdict in tableau):
        return 0
    return 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--sortie", default="resultats_ss6", help="dossier où garder les journaux")
    parser.add_argument("--travailleur", nargs=2, metavar=("DOSSIER", "GRAINE"), help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.travailleur:
        travailleur(Path(args.travailleur[0]), int(args.travailleur[1]))
    else:
        sys.exit(campagne(Path(args.sortie)))
