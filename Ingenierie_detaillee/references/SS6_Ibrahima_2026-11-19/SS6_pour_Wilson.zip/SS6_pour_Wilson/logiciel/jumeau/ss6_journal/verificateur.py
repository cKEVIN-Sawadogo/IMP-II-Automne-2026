"""SS-6 : le vérificateur.

On le lance après l'essai. Il a seulement la clé publique, donc il peut
vérifier les sceaux mais pas en fabriquer. Il fait cinq contrôles :
 (1) l'empreinte recalculée de chaque ligne est la même que celle enregistrée ;
 (2) les numéros de ligne se suivent et chaque ligne pointe vers la précédente ;
 (3) chaque sceau a une signature valide et correspond bien au journal ;
 (4) les sceaux couvrent tout le journal, sans trou, et le sceau final est là ;
 (5) une ligne par cycle (EX-Q-02) et une marque à chaque changement d'état (EX-F-10).

Pour le lancer :
    python -m jumeau.ss6_journal dossier_essai/            (ou --tout pour tout afficher)
"""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from dataclasses import dataclass, field
from pathlib import Path

# Pour pouvoir aussi le lancer avec « python verificateur.py dossier/ ».
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from jumeau.ss6_journal.ecrivain import (EMPREINTE_DEPART, NOM_JOURNAL, NOM_SCEAUX,
                                         dossier_cles_par_defaut, empreinte)
from jumeau.ss6_journal.scelleur import NOM_CLE_PUBLIQUE, message_sceau


@dataclass
class Rapport:
    entrees: int = 0
    cycles: int = 0
    sceaux: int = 0
    sceaux_rejetes: int = 0
    transitions: int = 0
    marques: int = 0
    sceau_final: bool = False
    anomalies: list = field(default_factory=list)   # liste de (seq ou None, message)

    @property
    def integre(self) -> bool:
        return len(self.anomalies) == 0

    @property
    def premiere_fautive(self):
        """Plus petit numéro de ligne qui pose problème (None s'il n'y en a pas)."""
        seqs = [seq for seq, _ in self.anomalies if seq is not None]
        return min(seqs) if seqs else None

    def texte(self, max_affiche=2) -> str:
        verdict = "INTÈGRE" if self.integre else "ALTÉRÉ OU INCOMPLET"
        lignes = [
            f"Verdict : {verdict}",
            f"entrées={self.entrees} cycles={self.cycles} sceaux={self.sceaux} "
            f"transitions={self.transitions} CHANGEMENT_ETAT={self.marques} "
            f"sceau final={'oui' if self.sceau_final else 'non'}",
        ]
        if max_affiche is None:
            a_montrer = self.anomalies
        else:
            a_montrer = self.anomalies[:max_affiche]
        for _, message in a_montrer:
            lignes.append(f"! {message}")
        reste = len(self.anomalies) - len(a_montrer)
        if reste > 0:
            lignes.append(f"... {reste} autre(s) anomalie(s)")
        return "\n".join(lignes)


def verifier(chemin, cle_publique=None, cycles_attendus=None) -> Rapport:
    """Vérifie un essai. `chemin` peut être le dossier de l'essai ou son journal.sqlite."""
    chemin = Path(chemin)
    journal = chemin / NOM_JOURNAL if chemin.is_dir() else chemin
    if not journal.exists():
        raise FileNotFoundError(journal)
    if cle_publique is None:
        cle_publique = dossier_cles_par_defaut(journal.parent) / NOM_CLE_PUBLIQUE

    r = Rapport()

    cx = sqlite3.connect(journal)
    lignes = cx.execute("SELECT sequence, contenu, empreinte_precedente, empreinte, k FROM journal ORDER BY sequence").fetchall()
    cx.close()
    r.entrees = len(lignes)

    # ---- Contrôles (1), (2) et (5) : on parcourt les lignes une par une.
    hash_par_seq = {}
    seq_attendue = 0
    hash_prec_attendu = EMPREINTE_DEPART
    k_prec = None
    etat_prec = None
    for seq, contenu, empreinte_precedente, h, k_sql in lignes:
        if seq != seq_attendue:
            r.anomalies.append((seq_attendue, f"seq {seq_attendue} : entrée absente ou séquence rompue (lu seq {seq})"))
        if empreinte_precedente != hash_prec_attendu:
            r.anomalies.append((seq, f"seq {seq} : maillon rompu (empreinte_precedente ne correspond pas)"))
        if empreinte(contenu, empreinte_precedente) != h:
            r.anomalies.append((seq, f"seq {seq} : empreinte recalculée différente (contenu altéré)"))
        hash_par_seq[seq] = h
        seq_attendue = seq + 1
        hash_prec_attendu = h

        try:
            donnees = json.loads(contenu)
        except ValueError:
            r.anomalies.append((seq, f"seq {seq} : contenu illisible"))
            continue
        if not isinstance(donnees, dict):
            r.anomalies.append((seq, "contenu du cycle invalide"))
            continue

        # Une ligne par cycle : les numéros de cycle doivent se suivre.
        k = donnees.get("k")
        if type(k) is not int or k != k_sql:
            r.anomalies.append((seq, "cycle absent, invalide ou différent de la colonne k"))
        if type(k) is int:
            if cycles_attendus is not None and k_prec is None and k != 0:
                r.anomalies.append((seq, "le premier cycle doit être zéro"))
            r.cycles += 1
            if k_prec is not None and k > k_prec + 2:
                r.anomalies.append((seq, f"cycles {k_prec + 1} à {k - 1} absents du journal (EX-Q-02)"))
            elif k_prec is not None and k == k_prec + 2:
                r.anomalies.append((seq, f"cycle {k_prec + 1} absent du journal (EX-Q-02)"))
            elif k_prec is not None and k <= k_prec:
                r.anomalies.append((seq, f"cycle {k} : en double ou en recul (EX-Q-02)"))
            k_prec = k

        # Chaque changement d'état doit avoir sa marque.
        marque = donnees.get("changement_etat")
        if marque:
            r.marques += 1
        etat = donnees.get("etat")
        if etat is not None:
            if etat_prec is not None and etat != etat_prec:
                r.transitions += 1
                bonne_marque = (isinstance(marque, dict) and marque.get("de") == etat_prec
                                and marque.get("vers") == etat)
                if not bonne_marque:
                    r.anomalies.append((seq, f"cycle {k} : changement d'état {etat_prec} → {etat} "
                                             f"sans marque CHANGEMENT_ETAT (EX-F-10)"))
            elif marque:
                r.anomalies.append((seq, f"cycle {k} : marque CHANGEMENT_ETAT sans changement d'état"))
            etat_prec = etat

    # ---- Contrôles (3) et (4) : les sceaux.
    derniere_seq = lignes[-1][0] if lignes else -1
    fichier_sceaux = journal.parent / NOM_SCEAUX
    if not fichier_sceaux.exists():
        r.anomalies.append((0 if lignes else None, "aucun sceau (sceaux.sqlite absent)"))
        return r

    cx = sqlite3.connect(fichier_sceaux)
    sceaux = cx.execute("SELECT numero, seq_debut, seq_fin, empreinte, final, horodatage, signature"
                        " FROM sceaux ORDER BY numero").fetchall()
    cx.close()
    r.sceaux = len(sceaux)

    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.serialization import load_pem_public_key
        cle = load_pem_public_key(Path(cle_publique).read_bytes())
    except (ImportError, OSError, ValueError) as erreur:
        r.anomalies.append((None, f"clé publique ou bibliothèque cryptography indisponible : {erreur}"))
        return r

    fin_couverte = -1   # dernière ligne couverte par un sceau valide
    for numero, debut, fin, emp, final, horodatage, signature in sceaux:
        # La signature doit être faite avec notre clé privée.
        try:
            cle.verify(bytes.fromhex(signature), message_sceau(numero, debut, fin, emp, final, horodatage))
        except (InvalidSignature, ValueError):
            r.sceaux_rejetes += 1
            r.anomalies.append((debut, f"sceau {numero} : signature invalide"))
            continue

        # L'empreinte signée doit être celle du journal.
        if fin < 0:
            attendue = EMPREINTE_DEPART
        else:
            attendue = hash_par_seq.get(fin)
        if attendue is None:
            r.anomalies.append((debut, f"sceau {numero} : la ligne seq {fin} n'est plus au journal"))
        elif attendue != emp:
            r.anomalies.append((debut, f"sceau {numero} : empreinte du bloc seq {debut}-{fin} "
                                       f"ne correspond pas au journal"))

        # Pas de trou entre les sceaux, et rien après le sceau final.
        if r.sceau_final:
            r.anomalies.append((debut, f"sceau {numero} : posé après le sceau final"))
        if debut > fin_couverte + 1:
            r.anomalies.append((fin_couverte + 1, f"entrées seq {fin_couverte + 1} à {debut - 1} sans sceau"))
        fin_couverte = max(fin_couverte, fin)
        if final:
            r.sceau_final = True

    if fin_couverte < derniere_seq:
        r.anomalies.append((fin_couverte + 1, f"entrées seq {fin_couverte + 1} à {derniere_seq} non scellées"))
    if not r.sceau_final:
        r.anomalies.append((None, "sceau final absent (arrêt non contrôlé)"))
    if cycles_attendus is not None and r.cycles != cycles_attendus:
        r.anomalies.append((None, f"{r.cycles} cycles au journal au lieu de {cycles_attendus} (EX-Q-02)"))
    return r


def verifier_journal(chemin, cle_publique=None):
    """Version courte pour les tests : (intègre ?, première ligne fautive, nombre d'entrées)."""
    r = verifier(chemin, cle_publique)
    return r.integre, r.premiere_fautive, r.entrees


def main(arguments=None) -> int:
    parser = argparse.ArgumentParser(description="Vérifie un journal SS-6 (chaîne SHA-256 et sceaux Ed25519).")
    parser.add_argument("dossier", help="dossier de l'essai (avec journal.sqlite et sceaux.sqlite)")
    parser.add_argument("--cle-publique", help="clé publique à utiliser (par défaut : cles_ss6/ à côté)")
    parser.add_argument("--cycles-attendus", type=int, help="nombre de cycles attendu (EX-Q-02)")
    parser.add_argument("--tout", action="store_true", help="afficher toutes les anomalies")
    args = parser.parse_args(arguments)

    r = verifier(args.dossier, args.cle_publique, args.cycles_attendus)
    print(r.texte(None if args.tout else 2))
    return 0 if r.integre else 1


if __name__ == "__main__":
    sys.exit(main())
