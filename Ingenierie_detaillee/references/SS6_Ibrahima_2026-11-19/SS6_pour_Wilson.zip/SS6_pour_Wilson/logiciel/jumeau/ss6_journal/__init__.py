"""SS-6 : journal de données et scellement signé.

Trois rôles, un fichier chacun :
  ecrivain.py      JournalDonnees : une ligne chaînée par cycle, sans clé
  scelleur.py      tourne à part, seul à lire la clé privée, un sceau tous les 60 cycles
  verificateur.py  après l'essai, avec la clé publique seulement

Entrée par cycle (clé de `entrees`) :
  contenu  dict  ce que l'orchestrateur veut garder (k, état, mesures, résidus, événements)
Sortie par cycle :
  {"sequence": n, "empreinte": empreinte}, rien qui puisse changer le diagnostic
"""
from jumeau.ss6_journal.ecrivain import EMPREINTE_DEPART, PERIODE_SCEAU, JournalDonnees
from jumeau.ss6_journal.verificateur import Rapport, verifier, verifier_journal
