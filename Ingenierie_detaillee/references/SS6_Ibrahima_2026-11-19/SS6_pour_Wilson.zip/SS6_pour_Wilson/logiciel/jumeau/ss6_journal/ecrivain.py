"""SS-6 : l'écrivain du journal.

À chaque cycle, on ajoute une ligne dans journal.sqlite. Chaque ligne garde
l'empreinte de la ligne d'avant, ce qui forme une chaîne :
    empreinte(i) = SHA-256(contenu(i) + empreinte(i-1))

L'écrivain n'a aucune clé. Tous les 60 cycles, il demande au scelleur
(scelleur.py, qui tourne dans un autre processus) de signer la dernière
empreinte. À l'arrêt normal, il demande le sceau final.
"""
from __future__ import annotations

import dataclasses
import enum
import hashlib
import json
import os
import platform
import sqlite3
import subprocess
import sys
from importlib import metadata
from pathlib import Path

from jumeau.interface import SousSysteme

EMPREINTE_DEPART = "0" * 64   # la première ligne pointe vers 64 zéros
PERIODE_SCEAU = 60            # un sceau tous les 60 cycles
NOM_JOURNAL = "journal.sqlite"
NOM_SCEAUX = "sceaux.sqlite"


def en_json(valeur):
    """Transforme les objets du contrat (Variable, Etat, Mesure, numpy...)
    en types simples que json sait écrire."""
    if isinstance(valeur, enum.Enum):
        return en_json(valeur.value)
    if dataclasses.is_dataclass(valeur) and not isinstance(valeur, type):
        return en_json(dataclasses.asdict(valeur))
    if isinstance(valeur, dict):
        resultat = {}
        for cle, v in valeur.items():
            if isinstance(cle, enum.Enum):   # ex. Variable.T devient "T"
                cle = cle.value
            resultat[str(cle)] = en_json(v)
        return resultat
    if isinstance(valeur, (set, frozenset)):
        return sorted((en_json(v) for v in valeur), key=str)
    if isinstance(valeur, (list, tuple)):
        return [en_json(v) for v in valeur]
    if isinstance(valeur, Path):
        return str(valeur)
    if hasattr(valeur, "tolist"):   # nombres et tableaux numpy
        return valeur.tolist()
    return valeur


def canonique(valeur) -> str:
    """Écrit toujours le contenu de la même façon (champs triés, sans espaces),
    pour que le vérificateur retrouve exactement la même empreinte."""
    return json.dumps(en_json(valeur), sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def empreinte(contenu: str, empreinte_prec: str) -> str:
    return hashlib.sha256((contenu + empreinte_prec).encode("utf-8")).hexdigest()


def dossier_cles_par_defaut(sortie) -> Path:
    """Les clés vont dans « cles_ss6 », à côté du dossier de l'essai,
    sauf si la variable JUMEAU_CLES_SS6 donne un autre dossier."""
    if os.environ.get("JUMEAU_CLES_SS6"):
        return Path(os.environ["JUMEAU_CLES_SS6"])
    return Path(sortie).resolve().parent / "cles_ss6"


def entete_essai(scenario: dict) -> dict:
    """En-tête de la première ligne : graine, versions et empreinte du scénario.
    Ça permet de rejouer l'essai plus tard (EX-F-02)."""
    versions = {"sqlite": sqlite3.sqlite_version}
    for nom in ("numpy", "cryptography"):
        try:
            versions[nom] = metadata.version(nom)
        except metadata.PackageNotFoundError:
            versions[nom] = "absente"
    return {
        "type": "entete_essai",
        "graine": scenario.get("graine"),
        "python": platform.python_version(),
        "bibliotheques": versions,
        "empreinte_scenario": hashlib.sha256(canonique(scenario).encode("utf-8")).hexdigest(),
    }


class JournalDonnees(SousSysteme):
    """SS-6 vu par l'orchestrateur : il écrit, il ne renvoie rien d'utile au diagnostic."""

    nom = "SS-6"

    def __init__(self, periode_sceau: int = PERIODE_SCEAU):
        super().__init__()
        self.periode_sceau = periode_sceau
        self.cx = None
        self.sequence = 0                    # numéro de la prochaine ligne
        self.dernier_cycle = None
        self.dernier_hash = EMPREINTE_DEPART
        self.etat_precedent = None
        self.entete = None
        self.scelleur = None

    def demarrer(self, contexte: dict) -> None:
        sortie = Path(contexte["sortie"])
        sortie.mkdir(parents=True, exist_ok=True)
        chemin = sortie / NOM_JOURNAL

        # Un essai = un dossier neuf, pour ne pas mélanger deux essais.
        if chemin.exists() or (sortie / NOM_SCEAUX).exists():
            raise FileExistsError(f"SS-6 : il y a déjà un journal dans {sortie}")

        self.cx = sqlite3.connect(chemin, check_same_thread=False)
        # Mode WAL : l'interface et le scelleur peuvent lire pendant qu'on écrit.
        self.cx.execute("PRAGMA journal_mode=WAL")
        self.cx.execute("PRAGMA synchronous=FULL")
        self.cx.execute("CREATE TABLE journal (sequence INTEGER PRIMARY KEY, k INTEGER NOT NULL, contenu TEXT NOT NULL,"
                        " empreinte_precedente TEXT NOT NULL, empreinte TEXT NOT NULL)")
        self.cx.commit()

        if contexte.get("scenario") is not None:
            self.entete = entete_essai(contexte["scenario"])

        cles = contexte.get("cles") or dossier_cles_par_defaut(sortie)
        self.scelleur = LienScelleur(chemin, sortie / NOM_SCEAUX, Path(cles))

    def etape(self, k: int, entrees: dict) -> dict:
        if self.cx is None:
            raise RuntimeError("SS-6 : il faut appeler demarrer() avant etape()")

        contenu = en_json(entrees.get("contenu", entrees))
        if not isinstance(contenu, dict):
            contenu = {"donnees": contenu}
        if contenu.get("k", k) != k:
            raise ValueError("Le cycle du contenu ne correspond pas au cycle transmis.")
        if type(k) is not int or k < 0:
            raise ValueError("Le cycle doit être un entier positif ou nul.")
        if self.dernier_cycle is not None and k != self.dernier_cycle + 1:
            raise ValueError("Les cycles doivent se suivre sans doublon.")
        contenu["k"] = k

        # Si l'état a changé depuis le cycle d'avant, on le note sur ce cycle (EX-F-10).
        etat = contenu.get("etat")
        if etat is not None:
            if self.etat_precedent is not None and etat != self.etat_precedent:
                contenu["changement_etat"] = {"de": self.etat_precedent, "vers": etat}
            self.etat_precedent = etat

        # Première ligne : on ajoute l'en-tête, sauf si l'orchestrateur l'a déjà mis.
        if self.sequence == 0 and self.entete is not None:
            evenements = contenu.get("evenements") or []
            deja_la = any(isinstance(e, dict) and e.get("type") == "entete_essai" for e in evenements)
            if not deja_la:
                contenu["evenements"] = [self.entete] + list(evenements)

        texte = canonique(contenu)
        h = empreinte(texte, self.dernier_hash)
        seq = self.sequence
        with self.cx:   # un cycle = une transaction : écrit en entier ou pas du tout
            self.cx.execute("INSERT INTO journal VALUES (?, ?, ?, ?, ?)", (seq, k, texte, self.dernier_hash, h))
        self.sequence += 1
        self.dernier_cycle = k
        self.dernier_hash = h

        if self.sequence % self.periode_sceau == 0:
            self.scelleur.demander(seq)
        return {"sequence": seq, "empreinte": h}

    def arreter(self) -> None:
        if self.cx is None:
            return   # déjà arrêté
        if self.scelleur is not None:
            self.scelleur.finir(self.sequence - 1)   # sceau final
            self.scelleur = None
        self.cx.close()
        self.cx = None

    @property
    def pid_scelleur(self):
        """Numéro du processus du scelleur (sert à l'essai d'arrêt brutal E6)."""
        return self.scelleur.proc.pid if self.scelleur else None


class LienScelleur:
    """Lance scelleur.py dans un autre processus et lui envoie les ordres
    « SCELLER n » et « FINAL n » par son entrée standard."""

    def __init__(self, journal: Path, sceaux: Path, cles: Path):
        programme = Path(__file__).parent / "scelleur.py"
        self.proc = subprocess.Popen(
            [sys.executable, str(programme), str(journal), str(sceaux), str(cles)],
            stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, text=True, encoding="utf-8")
        self.en_panne = False

    def envoyer(self, ordre: str) -> None:
        if self.en_panne:
            return
        try:
            self.proc.stdin.write(ordre + "\n")
            self.proc.stdin.flush()
        except (OSError, ValueError):
            # Le scelleur ne répond plus : on continue d'écrire, mais on le signale.
            self.en_panne = True
            print("SS-6 : le scelleur ne répond plus, les prochains cycles ne seront pas scellés",
                  file=sys.stderr)

    def demander(self, seq_fin: int) -> None:
        self.envoyer(f"SCELLER {seq_fin}")

    def finir(self, seq_fin: int) -> None:
        self.envoyer(f"FINAL {seq_fin}")
        try:
            self.proc.stdin.close()
        except OSError:
            pass
        # On attend que le scelleur ait fini d'écrire ses sceaux.
        try:
            code = self.proc.wait(timeout=60)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            code = None
        if code != 0:
            print(f"SS-6 : le scelleur s'est arrêté avec le code {code}", file=sys.stderr)
